// Programmer: Lane Murray
// Class: SDEV-200
// Date: 12/11/2021
// Program Name: Module 16: Semester Project Finalize
package com.example.semesterprojectjavafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class Module_16_Semester_Project_Finalize extends Application
{
    @Override
    public void start(Stage stage) throws IOException
    { // Creates a stage for Main Menu Scene.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("main-menu.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}