package com.example.semesterprojectjavafx;

// Programmer: Lane Murray
// Class: SDEV-200
// Date: 12/11/2021
// Program Name: Module 16: Semester Project Finalize
public class Vegetable extends Produce<String>
{
    boolean isOrganic;
    boolean isFresh;

    // Constructor for Vegetables, calls the super constructor.
    Vegetable(double price, String shelfLife, String name, double calories, double totalFat,
              double sodium, double cholesterol, double potassium, double totalCarbohydrates, double protein, boolean isOrganic, boolean isFresh)
    {
        super(price, shelfLife, name, "Vegetable", calories, totalFat, sodium, cholesterol, potassium, totalCarbohydrates, protein);
        this.isOrganic = isOrganic;
        this.isFresh = isFresh;
    }

    Vegetable() // Default Constructor, calls the super default constructor.
    {
        super();
        this.typeName = "Vegetable";
        this.isOrganic = false;
        this.isFresh = false;
    }

    String getInfo() // Returns the information for Vegetable.
    {
        return (this.name + " | $" + this.price + " | " + this.shelfLife + " | " + this.calories + " | " + this.totalFat + " | " + this.sodium + " | " + this.cholesterol + " | " + this.potassium + " | " +  this.totalCarbohydrates + " | " + this.protein + " | " + this.isFresh + " | " + this.isOrganic);
    }
}
