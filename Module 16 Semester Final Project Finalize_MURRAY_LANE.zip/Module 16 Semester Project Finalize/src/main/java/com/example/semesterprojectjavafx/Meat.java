package com.example.semesterprojectjavafx;

// Programmer: Lane Murray
// Class: SDEV-200
// Date: 12/11/2021
// Program Name: Module 16: Semester Project Finalize
public class Meat extends Produce<String>
{
    String usdaGrade;
    boolean isVegan;

    // Constructor for Meat, calls the super constructor.
    Meat(double price, String shelfLife, String name, double calories, double totalFat,
         double sodium, double cholesterol, double potassium, double totalCarbohydrates, double protein, String usdaGrade, boolean isVegan)
    {
        super(price, shelfLife, name, "Meat", calories, totalFat, sodium, cholesterol, potassium, totalCarbohydrates, protein);
        this.usdaGrade = usdaGrade;
        this.isVegan = isVegan;
    }

    Meat() // Default Constructor, calls the super default constructor.
    {
        super();
        this.typeName = "Meat";
        this.usdaGrade = "Select";
        this.isVegan = false;
    }

    String getInfo() // Returns the information for Meat.
    {
        return (this.name + " | $" + this.price + " | " + this.shelfLife + " | " + this.calories + " | " + this.totalFat + " | " + this.sodium + " | " + this.cholesterol + " | " + this.potassium + " | " +  this.totalCarbohydrates + " | " + this.protein + " | " + this.usdaGrade + " | " + this.isVegan);
    }

}
