// Programmer: Lane Murray
// Class: SDEV-200
// Date: 12/11/2021
// Program Name: Module 16: Semester Project Finalize
package com.example.semesterprojectjavafx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;
import java.util.Vector;

public class SceneController
{
    // This long list of variables is used for the JavaFX Buttons and Text Inputs.
    @FXML
    private Label myLabel;
    @FXML
    private TextField protein;
    @FXML
    private TextField totalCarbs;
    @FXML
    private TextField potassium;
    @FXML
    private TextField cholesterol;
    @FXML
    private TextField sodium;
    @FXML
    private TextField totalFat;
    @FXML
    private TextField calories;
    @FXML
    private TextField shelfLife;
    @FXML
    private TextField priceTxt;
    @FXML
    private TextField name;
    @FXML
    private TextField usdaGrade;
    @FXML
    private CheckBox organic;
    @FXML
    private CheckBox fresh;
    @FXML
    private CheckBox vegan;
    @FXML
    private TextArea infoOutput;

    private Stage stage;

    // These variables are used for storing data taken from the JavaFX elements.
    boolean isVegan, isOrganic, isFresh;
    String shelfLifeStr, nameStr, usdaGradeStr;
    double priceDub, caloriesDub, totalFatDub, sodiumDub, cholesterolDub, potassiumDub, totalCarbsDub, proteinDub;

    // Vectors for storing multiple different produce.
    public static Vector<Meat> meatVector = new Vector<>();
    public static Vector<Vegetable> vegetableVector = new Vector<>();
    public static Vector<Fruit> fruitVector = new Vector<>();

    public void exitButton() { System.exit(1);} // To end the program.

    public void switchToMainMenu(ActionEvent event) throws IOException
    { // Creates a stage for Main Menu Scene.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("main-menu.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToSelectGroceryScene(ActionEvent event) throws IOException
    { // Creates a stage for Select Grocery Scene.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("select-grocery-scene.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToVegetableScene(ActionEvent event) throws IOException
    { // Creates a stage for Vegetable Scene.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("vegetable-scene.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToProteinScene(ActionEvent event) throws IOException
    { // Creates a stage for Protein Scene.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("protein-scene.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToFruitScene(ActionEvent event) throws IOException
    { // Creates a stage for Fruit Scene.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("fruit-scene.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToViewProduceScene(ActionEvent event) throws IOException
    { // Creates a stage for View Produce Scene.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("view-produce-scene.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void submitProtein()
    {
        boolean errFlag = true;
        isVegan = vegan.isSelected();
        try
        {
            nameStr = name.getText();
            shelfLifeStr = shelfLife.getText();
            usdaGradeStr = usdaGrade.getText();
            priceDub = Double.parseDouble(priceTxt.getText());
            caloriesDub = Double.parseDouble(calories.getText());
            totalFatDub = Double.parseDouble(totalFat.getText());
            sodiumDub = Double.parseDouble(sodium.getText());
            cholesterolDub = Double.parseDouble(cholesterol.getText());
            potassiumDub = Double.parseDouble(potassium.getText());
            totalCarbsDub = Double.parseDouble(totalCarbs.getText());
            proteinDub = Double.parseDouble(protein.getText());
        }
        catch (NumberFormatException e)
        {
            myLabel.setText("Invalid Information Entered.");
            errFlag = false;
        }
        if (errFlag) // If no error is found, change scene text and add the previous information into a vector.
        {
            myLabel.setText("Enter another protein?");
            meatVector.add(new Meat(priceDub, shelfLifeStr, nameStr, caloriesDub, totalFatDub, sodiumDub, cholesterolDub, potassiumDub, totalCarbsDub, proteinDub, usdaGradeStr, isVegan));
        }
    }

    public void submitVegetable()
    {
        boolean errFlag = true;
        isFresh = fresh.isSelected();
        isOrganic = organic.isSelected();
        try
        {
            nameStr = name.getText();
            shelfLifeStr = shelfLife.getText();
            priceDub = Double.parseDouble(priceTxt.getText());
            caloriesDub = Double.parseDouble(calories.getText());
            totalFatDub = Double.parseDouble(totalFat.getText());
            sodiumDub = Double.parseDouble(sodium.getText());
            cholesterolDub = Double.parseDouble(cholesterol.getText());
            potassiumDub = Double.parseDouble(potassium.getText());
            totalCarbsDub = Double.parseDouble(totalCarbs.getText());
            proteinDub = Double.parseDouble(protein.getText());
        }
        catch (NumberFormatException e)
        {
            myLabel.setText("Invalid Information Entered.");
            errFlag = false;
        }
        if (errFlag) // If no error is found, change scene text and add the previous information into a vector.
        {
            myLabel.setText("Enter another vegetable?");
            vegetableVector.addElement(new Vegetable(priceDub, shelfLifeStr, nameStr, caloriesDub, totalFatDub, sodiumDub, cholesterolDub, potassiumDub, totalCarbsDub, proteinDub, isOrganic, isFresh));
        }
    }

    public void submitFruit()
    {
        boolean errFlag = true;
        isFresh = fresh.isSelected();
        isOrganic = organic.isSelected();
        try
        {
            nameStr = name.getText();
            shelfLifeStr = shelfLife.getText();
            priceDub = Double.parseDouble(priceTxt.getText());
            caloriesDub = Double.parseDouble(calories.getText());
            totalFatDub = Double.parseDouble(totalFat.getText());
            sodiumDub = Double.parseDouble(sodium.getText());
            cholesterolDub = Double.parseDouble(cholesterol.getText());
            potassiumDub = Double.parseDouble(potassium.getText());
            totalCarbsDub = Double.parseDouble(totalCarbs.getText());
            proteinDub = Double.parseDouble(protein.getText());
        }
        catch (NumberFormatException e)
        {
            myLabel.setText("Invalid Information Entered.");
            errFlag = false;
        }
        if (errFlag) // If no error is found, change scene text and add the previous information into a vector.
        {
            myLabel.setText("Enter another fruit?");
            fruitVector.addElement(new Fruit(priceDub, shelfLifeStr, nameStr, caloriesDub, totalFatDub, sodiumDub, cholesterolDub, potassiumDub, totalCarbsDub, proteinDub, isOrganic, isFresh));
        }
    }

    public void viewProtein() // Shows all protein stored.
    {
        infoOutput.setText("Name-Price-ShelfLife-Calories-Total Fat-Sodium-Cholesterol-Potassium-Total Carbs-Protein-USDA Grade-Vegan\n");
        if (!meatVector.isEmpty())
            for (Meat meat : meatVector) { infoOutput.appendText(meat.getInfo() + "\n"); }
        else
            infoOutput.appendText("No Protein Found.");
    }

    public void viewFruit() // Shows all fruit stored.
    {
        infoOutput.setText("Name-Price-ShelfLife-Calories-Total Fat-Sodium-Cholesterol-Potassium-Total Carbs-Protein-Fresh-Organic\n");
        if (!fruitVector.isEmpty())
            for (Fruit fruit : fruitVector) { infoOutput.appendText(fruit.getInfo() + "\n"); }
        else
            infoOutput.appendText("No Fruit Found.");
    }

    public void viewVegetable() // Shows all vegetables stored.
    {
        infoOutput.setText("Name-Price-ShelfLife-Calories-Total Fat-Sodium-Cholesterol-Potassium-Total Carbs-Protein-Fresh-Organic\n");
        if (!vegetableVector.isEmpty())
            for (Vegetable vegetable : vegetableVector) { infoOutput.appendText(vegetable.getInfo() + "\n"); }
        else
            infoOutput.appendText("No Vegetable Found.");
    }

    public void viewAll() // Shows all produce stored.
    {
        infoOutput.setText("Protein\n");
        infoOutput.appendText("Name-Price-ShelfLife-Calories-Total Fat-Sodium-Cholesterol-Potassium-Total Carbs-Protein-USDA Grade-Vegan\n");
        if (!meatVector.isEmpty())
            for (Meat meat : meatVector) { infoOutput.appendText(meat.getInfo() + "\n"); }
        else
            infoOutput.appendText("No Protein Found.");

        infoOutput.appendText("\n\nFruit\n");
        infoOutput.appendText("Name-Price-ShelfLife-Calories-Total Fat-Sodium-Cholesterol-Potassium-Total Carbs-Protein-Fresh-Organic\n");
        if (!fruitVector.isEmpty())
            for (Fruit fruit : fruitVector) { infoOutput.appendText(fruit.getInfo() + "\n"); }
        else
            infoOutput.appendText("No Fruit Found.");

        infoOutput.appendText("\n\nVegetable\n");
        infoOutput.appendText("Name-Price-ShelfLife-Calories-Total Fat-Sodium-Cholesterol-Potassium-Total Carbs-Protein-Fresh-Organic\n");
        if (!vegetableVector.isEmpty())
            for (Vegetable vegetable : vegetableVector) { infoOutput.appendText(vegetable.getInfo() + "\n"); }
        else
            infoOutput.appendText("No Vegetable Found.");
    }
}
