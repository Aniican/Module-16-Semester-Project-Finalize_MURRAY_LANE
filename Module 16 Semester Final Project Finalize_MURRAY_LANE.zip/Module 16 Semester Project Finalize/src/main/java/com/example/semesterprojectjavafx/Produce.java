package com.example.semesterprojectjavafx;

// Programmer: Lane Murray
// Class: SDEV-200
// Date: 11/21/2021
// Program Name: Module 12 Semester Project
public class Produce<T>
{
    double price;
    String shelfLife;
    String name;
    T typeName;

    double calories;
    double totalFat;
    double sodium;
    double cholesterol;
    double potassium;
    double totalCarbohydrates;
    double protein;

    // Constructor.
    Produce(double price, String shelfLife, String name, T typeName, double calories, double totalFat,
            double sodium, double cholesterol, double potassium, double totalCarbohydrates, double protein)
    {
        this.price = price;
        this.shelfLife = shelfLife;
        this.name = name;
        this.typeName = typeName;
        this.calories = calories;
        this.totalFat = totalFat;
        this.sodium = sodium;
        this.cholesterol = cholesterol;
        this.potassium = potassium;
        this.totalCarbohydrates = totalCarbohydrates;
        this.protein = protein;
    }

    Produce() // Default Constructor
    {
        this.price = 0;
        this.shelfLife = null;
        this.name = null;
        this.typeName = null;
        this.calories = 0;
        this.totalFat = 0;
        this.sodium = 0;
        this.cholesterol = 0;
        this.potassium = 0;
        this.totalCarbohydrates = 0;
        this.protein = 0;
    }

}
