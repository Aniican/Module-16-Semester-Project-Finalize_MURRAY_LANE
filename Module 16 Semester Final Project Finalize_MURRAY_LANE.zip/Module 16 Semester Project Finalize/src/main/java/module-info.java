module com.example.semesterprojectjavafx {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;


    opens com.example.semesterprojectjavafx to javafx.fxml;
    exports com.example.semesterprojectjavafx;
}